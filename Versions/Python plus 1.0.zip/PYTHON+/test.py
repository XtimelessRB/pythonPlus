import pythonPlus as p
print(p._version())
print(p._info())