###################################
# GLOBAL VARIABLE
###################################

info = {
    "name": "pythonPlus",
    "version": 1.0,
    "description": "A big python library with: math, formating and more",
    "author_name": "XtimelessRB",
    "author_email": "zelkomoj.studios@gmail.com",
    "author_url": "https://www.youtube.com/@Xtimeless",
    "license": "MIT",
    "keywords": [
        "python",
        "library"
    ],
    "packages": [
        "pythonPlus"
    ],
    "install_requires": [
        "none"
    ],
    "classifiers": [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
    "url": "https://github.com/XtimelessRB/pythonPlus/tree/pythonPlus/Versions",
}

###################################
# SETTINGS BLOCK
###################################

def _version():
    "Returns a version (str)"
    return info["version"]

def _info():
    "Returns a dictionary of info (dict)"
    stri = f"===Info===\nName: {info["name"]}\nVersion: {info["version"]}\nDescription: {info["description"]}\nAuthor: {info["author_name"]}, {info["author_email"]}, {info["author_url"]}\nLicense: {info["license"]}\nKeywords: {info["keywords"]}\nPackages: {info["packages"]}\nInstall Requires: {info["install_requires"]}\nClassifiers: {info["classifiers"]}\nUrl: {info["url"]}"
    return stri
###################################
# OTHER BLOCK
###################################

class MATH:
    def fact(x:int):
        "Returns a factorial of number (x!)"
        if x==0:
            return 1
        else:
            return x*MATH.fact(x-1)
    def isEven(n:float):
        "Returns boolean (True; False). Conditions: if n is even, return True else return False."
        if n % 2 == 0:
            return True
        else:
            return False
    def isPrime(n:int):
        "Returns boolean (True; False). Conditions: if n is prime, return True else return False."
        import math
        if n==1:
            return False
        for i in range(2,int(math.sqrt(n))+1):
            if n%i==0:
                return False
        return True
    def isPerfect(n:int):
        "Returns boolean (True; False). Conditions: if n is perfect, return True else return False."
        sum=0
        for i in range(1,n):
            if n%i==0:
                sum+=i
        if sum==n:
            return True
        else:
            return False
    def isFibonacci(n:int):
        "Returns boolean (True; False). Conditions: if n is fibonacci, return True else return False."
        a,b=0,1
        while b<=n:
            if b==n:
                return True
            a,b=b,a+b
        return False
    def fade(t:float):
        "Returns a fade (t * t * t * (t * (t * 6 - 15) + 10)) of t (float)"
        return t * t * t * (t * (t * 6 - 15) + 10)
    def lerp(t:float,a:float,b:float):
        "Returns a lerp (a + t * (b - a)) of t (float), a (float) & b (float)"
        return a + t * (b - a)
    def grad(hash,x:float,y:float,z:float):
        "Returns a grad (x if h < 8 else y if h < 4 else x if h == 12 or h == 14 else z) of hash (int), x (float), y (float) & z (float)"
        h = hash % 15
        u = x if h < 8 else y
        v = y if h < 4 else x if h == 12 or h == 14 else z
        return u if h & 1 == 0 else -u if h & 2 == 0 else v if h & 4 == 0 else -v
    def noise(x:float,y:float,z:float):
        "Returns a noise (Unknown) of x (float), y (float) & z (float)"
        import math
        X = int(math.floor(x)) & 255
        Y = int(math.floor(y)) & 255
        Z = int(math.floor(z)) & 255

        x -= math.floor(x)
        y -= math.floor(y)
        z -= math.floor(z)

        u = MATH.fade(x)
        v = MATH.fade(y)
        w = MATH.fade(z)

        A = hash(X) + Y
        AA = hash(A) + Z
        AB = hash(A + 1) + Z
        B = hash(X + 1) + Y
        BA = hash(B) + Z
        BB = hash(B + 1) + Z

        return MATH.lerp(w,MATH.lerp(v,MATH.lerp(u, MATH.grad(hash(AA),x,y,z),MATH.grad(hash(BA),x - 1, y,z)),MATH.lerp(u, MATH.grad(hash(AB),x,y-1,z),MATH.grad(hash(BB),x - 1, y-1,z))),MATH.lerp(v,MATH.lerp(u, MATH.grad(hash(AA+1),x,y,z-1),MATH.grad(hash(BA+1),x - 1, y,z-1)),MATH.lerp(u, MATH.grad(hash(AB+1),x,y-1,z-1),MATH.grad(hash(BB+1),x - 1, y-1,z-1))))
    def sec(x:float):
        "Returns a sec(x) on formula: 1/cos(x)"
        import math
        return 1/math.cos(x)
    def csc(x:float):
        "Returns a csc(x) on formula: 1/sin(x)"
        import math
        return 1/math.sin(x)
    def cot(x:float):
        "Returns a cot(x) on formula: cos(x)/sin(x)"
        import math
        return math.cos(x)/math.sin(x)
    def asec(x:float):
        "Returns an arcsec on formula: arccos(1/x)"
        import math
        return math.acos(1/x)
    def acsc(x:float):
        "Returns an arccsc on formula: arcsin(1/x)"
        import math
        return math.asin(1/x)
    def acot(x:float):
        "Returns an arccot on formula: arctan(1/x)"
        import math
        return math.atan(1/x)
    def coth(x:float):
        "Returns a coth on formula: ((e^x)+(e^-x))/((e^x)-(e^-x))"
        import math
        return (math.exp(x)+math.exp(-x))/(math.exp(x)-math.exp(-x))
    def sech(x:float):
        "Returns a sech on formula: 2/((e^x)+(e^-x))"
        import math
        return 2/(math.exp(x)+math.exp(-x))
    def csch(x:float):
        "Returns a csch on formula: 2/((e^x)-(e^-x))"
        import math
        return 2/(math.exp(x)-math.exp(-x))
    def acoth(x:float):
        "Returns an arccoth on formula: 0.5*ln((x+1)/(x-1))"
        import math
        return 0.5*math.log((x+1)/(x-1))
    def asech(x:float):
        "Returns an arcsech on formula: ln((1/x)+√((1/(x^2))-1))"
        import math
        return math.log((1/x)+math.sqrt((1/math.pow(x,2))-1))
    def acsch(x:float):
        "Returns an arccsch on formula: ln((1/x)+√((1/(x^2))+1))"
        import math
        return math.log((1/x)+math.sqrt((1/math.pow(x,2))+1))
    def sin(x:float):
        "Returns a sin on formula: A/C"
        import math
        return math.sin(x)
    def cos(x:float):
        "Returns a cos on formula: B/C"
        import math
        return math.cos(x)
    def tan(x:float):
        "Returns a tan on formula: A/B"
        import math
        return math.tan(x)
    def asin(x:float):
        "Returns an arcsin on formula: C/A"
        import math
        return math.asin(x)
    def acos(x:float):
        "Returns an arccos on formula: C/B"
        import math
        return math.acos(x)
    def atan(x:float):
        "Returns an arctan on formula: B/A"
        import math
        return math.atan(x)
    def sinh(x:float):
        "Returns a sinh on formula: ((e^x)-(e^-x))/2"
        import math
        return math.sinh(x)
    def cosh(x:float):
        "Returns a cosh on formula: ((e^x)+(e^-x))/2"
        import math
        return math.cosh(x)
    def tanh(x:float):
        "Returns a tanh on formula: ((e^x)-(e^-x))/((e^x)+(e^-x))"
        import math
        return math.tanh(x)
    def asinh(x:float):
        "Returns an arcsinh on formula: ln(x+√((x^2)+1))"
        import math
        return math.asinh(x)
    def acosh(x:float):
        "Returns an arccosh on formula: ln(x+√((x^2)-1))"
        import math
        return math.acosh(x)
    def atanh(x:float):
        "Returns an arctanh on formula: 0.5*ln((1+x)/(1-x))"
        import math
        return math.atanh(x)
    def exp(x:float):
        "Returns an exp (float) on formula: e^x"
        import math
        return math.exp(x)
    class Constant:
        "Returns constants: C, e, π,..."
        import math
        C = 0
        e = math.e
        pi = math.pi
        phi = (1 + math.sqrt(5)) / 2
        tau = 2 * pi
        sqrt2 = math.sqrt(2)
        nan = math.nan
        inf = math.inf
        c = 299_792_458
        def setC(c0:float):
            C = c0
            return True
    def pow(x:float,k:float):
        "Returns a pow (float) on formula: x^k"
        return x**k
    def sqrt(x:float):
        "Returns a sqrt (float) on formula: √x"
        import math
        return math.sqrt(x)
    def cbrt(x:float):
        "Returns a cbrt (float) on formula: ∛x"
        import math
        return math.cbrt(x)
    def rt(x:float,power:int):
        "Returns a rt (float) on formula: x^(1/power)"
        import math
        return math.pow(x,1/power)
    def ln(x:float):
        "Returns a log (float) on formula: ln(x)"
        import math
        return math.log(x)
    def log(x:float,base:float):
        "Returns a log (float) on formula: ln(x)/ln(base)"
        import math
        return math.log(x)/math.log(base)
    def lg(x:float):
        "Returns a lg (float) on formula: ln(x)/ln(10)"
        import math
        return math.log(x)/math.log(10)
    def lb(x:float):
        "Returns a lb (float) on formula: ln(x)/ln(2)"
        import math
        return math.log(x)/math.log(2)
    def gcf(x:int,y:int):
        "Returns a gcf (int) on formula: gcd(x,y)"
        import math
        return math.gcd(x,y)
    def lcm(x:int,y:int):
        "Returns a lcm (int) on formula: lcm(x,y)"
        import math
        return math.lcm(x,y)
    def gcd(x:int,y:int):
        "Returns a gcd (int) on formula: gcd(x,y)"
        import math
        return math.gcd(x,y)
    def sign(x:float):
        "Returns a sign (int) on formula: sign(x)"
        import math
        return math.copysign(1,x)
    def abs(x:float):
        "Returns a abs (float) on formula: abs(x)"
        import math
        return math.fabs(x)
    def floor(x:float):
        "Returns a floor (float) on formula: floor(x)"
        import math
        return math.floor(x)
    def ceil(x:float):
        "Returns a ceil (float) on formula: ceil(x)"
        import math
        return math.ceil(x)
    def round(x:float):
        "Returns a round (float) on formula: round(x)"
        import math
        return math.round(x)
    def trunc(x:float):
        "Returns a trunc (float) on formula: trunc(x)"
        import math
        return math.trunc(x)
    def frac(x:float):
        "Returns a frac (float) on formula: x-trunc(x)"
        import math
        return x-math.trunc(x)
    def fmod(x:float,y:float):
        "Returns a fmod (float) on formula: x%y"
        import math
        return math.fmod(x,y)
    def modf(x:float):
        "Returns a modf (float) on formula: modf(x)"
        import math
        return math.modf(x)
    def mod(x:float,y:float):
        "Returns a mod (float) on formula: x%y"
        import math
        return math.fmod(x,y)
    def hypot(x:float,y:float):
        "Returns a hypot (float) on formula: √(x^2+y^2)"
        import math
        return math.hypot(x,y)
    def degrees(x:float):
        "Returns a degrees (float) on formula: x*180/π"
        import math
        return x*180/math.pi
    def radians(x:float):
        "Returns a radians (float) on formula: x*π/180"
        import math
        return x*math.pi/180
    def integral(coefficient:float,lowerLim:float,upperLim:float):
        "Returns a ∫ (float) on formula: (coefficient*(upperLim^2-lowerLim^2))/2"
        import math
        return (coefficient*(math.pow(upperLim,2)-math.pow(lowerLim,2)))/2
    def gamma(x:float):
        "Returns a Γ (float) on formula: Γ(x)"
        import math
        return math.gamma(x)
    def beta(v:float) -> float:
        "Returns a β (float) on formula: (v/c)*100%, v must be in m/s; c - light speed"
        import math
        return (v/MATH.Constant.c)*100
    def summ(x:int,y:int):
        "Returns a summ (int) on formula: x+y"
        import math
        return sum(y + i for i in range(x+1))
    def prod(x:int,y:int):
        "Returns a prod (int) on formula: x*y"
        import math
        return math.prod(y + i for i in range(x+1))
    def sap(x:float):
        "Returns a sap (float) on formula: tan(x)/cos(x)"
        import math
        return math.tan(x)/math.cos(x)
    def cim(x:float):
        "Returns a cim (float) on formula: tan(x)/sin(x)"
        import math
        return math.tan(x)/math.sin(x)
    def asap(x:float):
        "Returns an arcsap (float) on formula: cos(x)/tan(X)"
        import math
        return math.cos(x)/math.tan(x)
    def acim(x:float):
        "Returns a arccim (float) on formula: sin(x)/tan(x)"
        import math
        return math.sin(x)/math.tan(x)
    def saph(x:float):
        "Returns a saph (float) on formula: 1/sap(x)"
        import math
        return 1/MATH.sap(x)
    def cimh(x:float):
        "Returns a cimh (float) on formula: 1/cim(x)"
        import math
        return 1/MATH.cim(x)
    def asaph(x:float):
        "Returns an arcsaph (float) on formula: 1/arcsap(x)"
        import math
        return 1/MATH.asap(x)
    def acimh(x:float):
        "Returns a arccimh (float) on formula: 1/arccim(x)"
        import math
        return 1/MATH.acim(x)
    def factdouble(x:int,y:int):
        "Returns a double factorial (int) on formula: x*(x-2)*(x-4)*...*2"
        import math
        return math.prod(y + i for i in range(x+1,0,-2))
    def remainder(x:float,y:float):
        "Returns a remainder (float) on formula: x%y"
        import math
        return math.remainder(x,y)
    def perm(n:int,r:int):
        "Returns a perm (int) on formula: n!/(n-r)!"
        import math
        return math.factorial(n)/math.factorial(n-r)
    def comb(n:int,r:int):
        "Returns a comb (int) on formula: n!/r!(n-r)!"
        import math
        return math.factorial(n)/math.factorial(r)/math.factorial(n-r)
    def isclose(a:float,b:float,rel_tol:float=1e-09,abs_tol:float=0.0):
        "Returns a isclose (bool) on formula: abs(a-b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)"
        import math
        return math.isclose(a,b,rel_tol=rel_tol,abs_tol=abs_tol)
    def isfinite(x:float):
        "Returns a isfinite (bool) on formula: x is finite"
        import math
        return math.isfinite(x)
    def isinf(x:float):
        "Returns a isinf (bool) on formula: x is infinite"
        import math
        return math.isinf(x)
    def isnan(x:float):
        "Returns a isnan (bool) on formula: x is NaN"
        import math
        return math.isnan(x)
    
class Output:
    def out(*values: object, sep: str | None = " ", end: str | None = "\n", file: str| None = None, flush: False = False):
            "Prints the values to the standard output"
            print(*values, sep=sep, end=end, file=file, flush=flush)
    class Error:
        def TypeErr(*args):
            "Prints the values to the type error"
            TypeError(*args)
        def ValueErr(*args):
            "Prints the values to the value error"
            ValueError(*args)
        def NameErr(*args):
            "Prints the values to the name error"
            NameError(*args)
        def SyntaxErr(*args):
            "Prints the values to the syntax error"
            SyntaxError(*args)
        def IndErr(*args):
            "Prints the values to the indentation error"
            IndentationError(*args)
        def UnboundErr(*args):
            "Prints the values to the unbound error"
            UnboundLocalError(*args)
        def ZeroDivErr(*args):
            "Prints the values to the zero division error"
            ZeroDivisionError(*args)
        def OverflowErr(*args):
            "Prints the values to the overflow error"
            OverflowError(*args)
        def SystemErr(*args):
            "Prints the values to the system error"
            SystemError(*args)
        def ImportErr(*args):
            "Prints the values to the import error"
            ImportError(*args)
        def FileErr(*args):
            "Prints the values to the file error"
            FileNotFoundError(*args)
        def EOFErr(*args):
            "Prints the values to the end of file error"
            EOFError(*args)
        def SystemExitErr(*args):
            "Prints the values to the system exit error"
            SystemExit(*args)
        def KeyboardInterruptErr(*args):
            "Prints the values to the keyboard interrupt error"
            KeyboardInterrupt(*args)
        def GeneratorExitErr(*args):
            "Prints the values to the generator exit error"
            GeneratorExit(*args)
        def RecursionErr(*args):
            "Prints the values to the recursion error"
            RecursionError(*args)
        def AssertionErrorErr(*args):
            "Prints the values to the assertion error"
            AssertionError(*args)
        def AttributeErrorErr(*args):
            "Prints the values to the attribute error"
            AttributeError(*args)
        def LookupErr(*args):
            "Prints the values to the lookup error"
            LookupError(*args)
    class Warning:
        def UserWarn(*args):
            "Prints the values to the user warning"
            UserWarning(*args)
        def DeprecationWarn(*args):
            "Prints the values to the deprecation warning"
            DeprecationWarning(*args)
        def PendingDeprecationWarn(*args):
            "Prints the values to the pending deprecation warning"
            PendingDeprecationWarning(*args)
        def RuntimeWarn(*args):
            "Prints the values to the runtime warning"
            RuntimeWarning(*args)
        def SyntaxWarn(*args):
            "Prints the values to the syntax warning"
            SyntaxWarning(*args)
        def FutureWarn(*args):
            "Prints the values to the future warning"
            FutureWarning(*args)
        def ImportWarn(*args):
            "Prints the values to the import warning"
            ImportWarning(*args)
        def UnicodeWarn(*args):
            "Prints the values to the unicode warning"
            UnicodeWarning(*args)
        def BytesWarn(*args):
            "Prints the values to the bytes warning"
            BytesWarning(*args)
        def ResourceWarn(*args):
            "Prints the values to the resource warning"
            ResourceWarning(*args)
        def DeprecationWarn(*args):
            "Prints the values to the deprecation warning"
            DeprecationWarning(*args)
        def PendingDeprecationWarn(*args):
            "Prints the values to the pending deprecation warning"
            PendingDeprecationWarning(*args)
class Format:
    class Time:
        def hh_mm_ss(sec:int):
            "Returns a hh:mm:ss (str) on formula: hh:mm:ss"
            import time
            return time.strftime("%H:%M:%S", time.gmtime(sec))
        def hh_mm(sec:int):
            "Returns a hh:mm (str) on formula: hh:mm"
            import time
            return time.strftime("%H:%M", time.gmtime(sec))
        def mm_ss(sec:int):
            "Returns a mm:ss (str) on formula: mm:ss"
            import time
            return time.strftime("%M:%S", time.gmtime(sec))
        def mm(sec:int):
            "Returns a mm (str) on formula: mm"
            import time
            return time.strftime("%M", time.gmtime(sec))
        def ss(sec:int):
            "Returns a ss (str) on formula: ss"
            import time
            return time.strftime("%S", time.gmtime(sec))
        def hh(sec:int):
            "Returns a hh (str) on formula: hh"
            import time
            return time.strftime("%H", time.gmtime(sec))
        def dd_hh_mm_ss(sec:float):
            "Returns a dd:hh:mm:ss (str) on formula: dd:hh:mm:ss"
            import time
            return time.strftime("%D:%H:%M:%S", time.gmtime(sec))
        def dd_hh_mm(sec:float):
            "Returns a dd:hh:mm (str) on formula: dd:hh:mm"
            import time
            return time.strftime("%D:%H:%M", time.gmtime(sec))
        def dd_mm_ss(sec:float):
            "Returns a dd:mm:ss (str) on formula: dd:mm:ss"
            import time
            return time.strftime("%D:%M:%S", time.gmtime(sec))
        def dd_mm(sec:float):
            "Returns a dd:mm (str) on formula: dd:mm"
            import time
            return time.strftime("%D:%M", time.gmtime(sec))
        def dd_ss(sec:float):
            "Returns a dd:ss (str) on formula: dd:ss"
            import time
            return time.strftime("%D:%S", time.gmtime(sec))
        def dd_hh(sec:float):
            "Returns a dd:hh (str) on formula: dd:hh"
            import time
            return time.strftime("%D:%H", time.gmtime(sec))
    class Date:
        def dd_mm_yy(day:int):
            "Returns a dd.mm.yy (str) on formula: dd.mm.yy"
            import time
            return time.strftime("%d.%m.%y", time.gmtime(day))
        def dd_mm_yyyy(day:int):
            "Returns a dd.mm.yyyy (str) on formula: dd.mm.yyyy"
            import time
            return time.strftime("%d.%m.%Y", time.gmtime(day))
        def mm_dd_yy(day:int):
            "Returns a mm.dd.yy (str) on formula: mm.dd.yy"
            import time
            return time.strftime("%m.%d.%y", time.gmtime(day))
        def mm_dd_yyyy(day:int):
            "Returns a mm.dd.yyyy (str) on formula: mm.dd.yyyy"
            import time
            return time.strftime("%m.%d.%Y", time.gmtime(day))
        def yy_mm_dd(day:int):
            "Returns a yy.mm.dd (str) on formula: yy.mm.dd"
            import time
            return time.strftime("%y.%m.%d", time.gmtime(day))
        def yyyy_mm_dd(day:int):
            "Returns a yyyy.mm.dd (str) on formula: yyyy.mm.dd"
            import time
            return time.strftime("%Y.%m.%d", time.gmtime(day))
    class Number:
        def bin(x:int):
            "Returns a bin (str) on formula: bin(x)"
            import math
            return bin(x)
        def oct(x:int):
            "Returns a oct (str) on formula: oct(x)"
            import math
            return oct(x)
        def hex(x:int):
            "Returns a hex (str) on formula: hex(x)"
            import math
            return hex(x)
        def dec(x:int):
            "Returns a dec (str) on formula: dec(x)"
            import math
            return str(x)
    class Random:
        def randint(x:int,y:int):
            "Returns a randint (int) on formula: randint(x,y)"
            import random
            return random.randint(x,y)
        def randrange(x:int,y:int):
            "Returns a randrange (int) on formula: randrange(x,y)"
            import random
            return random.randrange(x,y)
        def random():
            "Returns a random (float) on formula: random()"
            import random
            return random.random()
        def uniform(x:float,y:float):
            "Returns a uniform (float) on formula: uniform(x,y)"
            import random
            return random.uniform(x,y)
        def shuffle(x:list):
            "Returns a shuffle (list) on formula: shuffle(x)"
            import random
            return random.shuffle(x)
        def choice(x:list):
            "Returns a choice (list) on formula: choice(x)"
            import random
            return random.choice(x)
        def sample(x:list,y:int):
            "Returns a sample (list) on formula: sample(x,y)"
            import random
            return random.sample(x,y)